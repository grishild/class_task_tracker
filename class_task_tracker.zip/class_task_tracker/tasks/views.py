from django.utils import timezone
from rest_framework import viewsets, permissions, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied
from django_filters.rest_framework import DjangoFilterBackend

from .models import Task, TaskSubmission
from .serializers import TaskSerializer


class TaskViewSet(viewsets.ModelViewSet):
    serializer_class = TaskSerializer
    permission_classes = [permissions.IsAuthenticated]

    filter_backends = [
        filters.SearchFilter,
        DjangoFilterBackend
    ]

    search_fields = ['title']
    filterset_fields = ['classroom']

    def get_queryset(self):
        user = self.request.user

        if user.role == 'teacher':
            queryset = Task.objects.filter(
                classroom__teacher=user
            )
        else:
            queryset = Task.objects.filter(
                classroom__memberships__student=user
            ).distinct()

        status = self.request.query_params.get('status')

        if user.role == 'student':
            if status == 'completed':
                queryset = queryset.filter(
                    submissions__student=user,
                    submissions__is_completed=True
                )
            elif status == 'pending':
                queryset = queryset.exclude(
                    submissions__student=user,
                    submissions__is_completed=True
                )

        return queryset

    def perform_create(self, serializer):
        if self.request.user.role != 'teacher':
            raise PermissionDenied(
                'Hanya guru yang dapat membuat tugas.'
            )

        classroom = serializer.validated_data['classroom']

        if classroom.teacher != self.request.user:
            raise PermissionDenied(
                'Anda hanya dapat membuat tugas di kelas milik Anda.'
            )

        serializer.save()

    def update(self, request, *args, **kwargs):
        if request.user.role != 'teacher':
            raise PermissionDenied(
                'Siswa tidak dapat mengubah tugas.'
            )

        return super().update(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        if request.user.role != 'teacher':
            raise PermissionDenied(
                'Siswa tidak dapat mengubah tugas.'
            )

        return super().partial_update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        if request.user.role != 'teacher':
            raise PermissionDenied(
                'Siswa tidak dapat menghapus tugas.'
            )

        return super().destroy(request, *args, **kwargs)

    @action(detail=True, methods=['post'])
    def complete(self, request, pk=None):
        if request.user.role != 'student':
            raise PermissionDenied(
                'Hanya siswa yang dapat menyelesaikan tugas.'
            )

        task = self.get_object()

        submission, created = TaskSubmission.objects.update_or_create(
            task=task,
            student=request.user,
            defaults={
                'is_completed': True,
                'completed_at': timezone.now()
            }
        )

        return Response({
            'message': 'Tugas berhasil diselesaikan.',
            'task_id': task.id,
            'is_completed': submission.is_completed,
            'completed_at': submission.completed_at
        })