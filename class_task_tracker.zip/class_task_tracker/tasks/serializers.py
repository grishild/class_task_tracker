from rest_framework import serializers
from .models import Task


class TaskSerializer(serializers.ModelSerializer):
    is_completed = serializers.SerializerMethodField()

    class Meta:
        model = Task
        fields = [
            'id',
            'title',
            'description',
            'deadline',
            'classroom',
            'is_completed',
            'created_at',
            'updated_at'
        ]
        read_only_fields = [
            'id',
            'is_completed',
            'created_at',
            'updated_at'
        ]

    def get_is_completed(self, obj):
        user = self.context['request'].user

        if user.role == 'student':
            submission = obj.submissions.filter(
                student=user
            ).first()

            return submission.is_completed if submission else False

        return None