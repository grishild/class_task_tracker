
from rest_framework import serializers
from .models import Classroom, ClassMembership
from django.contrib.auth import get_user_model

User = get_user_model()


class ClassroomSerializer(serializers.ModelSerializer):
    teacher = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Classroom
        fields = ['id', 'name', 'description', 'teacher', 'created_at']
        read_only_fields = ['id', 'teacher', 'created_at']


class ClassMembershipSerializer(serializers.ModelSerializer):
    student_username = serializers.CharField(
        write_only=True
    )
    student = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = ClassMembership
        fields = ['id', 'student_username', 'student', 'classroom', 'joined_at']
        read_only_fields = ['id', 'student', 'classroom', 'joined_at']

    def validate_student_username(self, value):
        try:
            student = User.objects.get(username=value)
        except User.DoesNotExist:
            raise serializers.ValidationError('Siswa tidak ditemukan.')

        if student.role != User.Role.STUDENT:
            raise serializers.ValidationError('Pengguna bukan siswa.')

        return value

    def create(self, validated_data):
        username = validated_data.pop('student_username')
        student = User.objects.get(username=username)

        return ClassMembership.objects.create(
            student=student,
            **validated_data
        )
