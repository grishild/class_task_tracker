
from rest_framework import generics, permissions
from rest_framework.exceptions import PermissionDenied
from .models import Classroom, ClassMembership
from .serializers import ClassroomSerializer, ClassMembershipSerializer


class ClassroomListCreateView(generics.ListCreateAPIView):
    serializer_class = ClassroomSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user

        if user.role == 'teacher':
            return Classroom.objects.filter(teacher=user)

        return Classroom.objects.filter(
            memberships__student=user
        ).distinct()

    def perform_create(self, serializer):
        if self.request.user.role != 'teacher':
            raise PermissionDenied('Hanya guru yang dapat membuat kelas.')

        serializer.save(teacher=self.request.user)


class ClassMembershipCreateView(generics.CreateAPIView):
    serializer_class = ClassMembershipSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        classroom_id = self.kwargs['classroom_id']

        try:
            classroom = Classroom.objects.get(
                id=classroom_id,
                teacher=self.request.user
            )
        except Classroom.DoesNotExist:
            raise PermissionDenied(
                'Kelas tidak ditemukan atau bukan milik Anda.'
            )

        serializer.save(classroom=classroom)
