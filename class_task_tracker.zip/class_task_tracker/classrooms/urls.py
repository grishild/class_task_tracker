from django.urls import path
from .views import (
    ClassroomListCreateView,
    ClassMembershipCreateView
)

urlpatterns = [
    path('', ClassroomListCreateView.as_view(), name='classroom-list'),
    path(
        '<int:classroom_id>/students/',
        ClassMembershipCreateView.as_view(),
        name='classroom-add-student'
    ),
]