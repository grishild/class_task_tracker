# Class Task Tracker

Aplikasi pengelolaan tugas sekolah berbasis web yang dibangun menggunakan Django REST Framework sebagai backend API dan MariaDB sebagai database.

Aplikasi ini dirancang untuk membantu guru mengelola tugas serta membantu siswa melihat dan memantau penyelesaian tugas.

## 1. Teknologi yang Digunakan

- Python
- Django
- Django REST Framework
- MariaDB
- Django Simple JWT
- HTML, CSS, JavaScript (frontend — dalam pengembangan)

## 2. Fitur Aplikasi

### Authentication
- Registrasi akun siswa.
- Login menggunakan username dan password.
- Autentikasi menggunakan JSON Web Token (JWT).
- Pembagian role pengguna menjadi guru dan siswa.
- Password disimpan menggunakan mekanisme hashing Django.

### Classroom Management
- Guru dapat membuat kelas.
- Guru dapat melihat kelas miliknya.
- Guru dapat menambahkan siswa ke kelas.
- Siswa dapat melihat kelas yang diikutinya.

### Task Management
- Guru dapat membuat tugas.
- Guru dapat melihat daftar tugas.
- Guru dapat memperbarui dan menghapus tugas.
- Siswa dapat melihat tugas dari kelas yang diikutinya.
- Siswa dapat menandai tugas sebagai selesai.

### Task Search and Filtering
- Pencarian tugas berdasarkan judul.
- Filter tugas berdasarkan kelas.
- Filter status penyelesaian tugas siswa.

## 3. Persyaratan Sistem

Sebelum menjalankan aplikasi, pastikan sudah tersedia:

- Python 3.12 atau versi yang kompatibel.
- MariaDB 10.11 atau lebih baru.
- Git.
- Postman (untuk pengujian API).

## 4. Cara Instalasi dan Menjalankan Aplikasi

### Langkah 1 — Clone Repository

```bash
git clone https://github.com/USERNAME/class_task_tracker.git
```

Masuk ke folder proyek:

```bash
cd class_task_tracker
```

### Langkah 2 — Membuat Virtual Environment

```bash
python -m venv venv
```

Aktifkan virtual environment.

Windows PowerShell:

```powershell
.\venv\Scripts\Activate.ps1
```

### Langkah 3 — Install Dependencies

```bash
pip install -r requirements.txt
```

### Langkah 4 — Konfigurasi Environment

Salin file `.env.example` menjadi `.env`.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Sesuaikan konfigurasi database di dalam `.env` dengan pengaturan MariaDB lokal.

### Langkah 5 — Membuat Database

Masuk ke MariaDB, kemudian jalankan:

```sql
CREATE DATABASE class_task_tracker
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

### Langkah 6 — Menjalankan Migrasi

```bash
python manage.py migrate
```

### Langkah 7 — Membuat Akun Administrator

```bash
python manage.py createsuperuser
```

### Langkah 8 — Menjalankan Server

```bash
python manage.py runserver
```

Server berjalan pada:

```text
http://127.0.0.1:8000/
```

## 5. Contoh Akun Pengujian

Akun berikut digunakan untuk pengujian selama pengembangan.

| Role | Username | Password |
|---|---|---|
| Guru | guru01 | Gunakan password demo yang telah dikonfigurasi |
| Siswa | siswaputri | Gunakan password demo yang telah dikonfigurasi |

Catatan:
- Akun guru dibuat melalui Django Shell atau Django Admin.
- Registrasi melalui API secara default membuat akun dengan role siswa.
- Gunakan akun demo dengan password khusus pengujian, bukan password akun pribadi.

## 6. Daftar Endpoint API

Base URL:

```text
http://127.0.0.1:8000/api/
```

### Authentication

| Method | Endpoint | Keterangan |
|---|---|---|
| POST | `/auth/register/` | Registrasi siswa |
| POST | `/auth/login/` | Login dan memperoleh token |
| POST | `/auth/token/refresh/` | Memperbarui access token |

### Classroom

| Method | Endpoint | Keterangan |
|---|---|---|
| GET | `/classrooms/` | Melihat daftar kelas |
| POST | `/classrooms/` | Membuat kelas (guru) |
| POST | `/classrooms/{id}/students/` | Menambahkan siswa ke kelas (guru) |

### Tasks

| Method | Endpoint | Keterangan |
|---|---|---|
| GET | `/tasks/` | Melihat daftar tugas |
| POST | `/tasks/` | Membuat tugas (guru) |
| GET | `/tasks/{id}/` | Melihat detail tugas |
| PUT | `/tasks/{id}/` | Memperbarui tugas (guru) |
| PATCH | `/tasks/{id}/` | Memperbarui sebagian data tugas (guru) |
| DELETE | `/tasks/{id}/` | Menghapus tugas (guru) |
| POST | `/tasks/{id}/complete/` | Menandai tugas selesai (siswa) |

### Query Parameters

Pencarian berdasarkan judul:

```text
GET /tasks/?search=CRUD
```

Filter berdasarkan kelas:

```text
GET /tasks/?classroom=1
```

Filter status penyelesaian siswa:

```text
GET /tasks/?status=completed
GET /tasks/?status=pending
```

Endpoint yang membutuhkan autentikasi harus menggunakan:

```text
Authorization: Bearer <access_token>
```

## 7. Keputusan Desain

Beberapa keputusan desain yang diterapkan dalam pengembangan aplikasi:

1. Menggunakan Django REST Framework untuk membangun REST API agar backend dapat diakses oleh berbagai frontend.
2. Menggunakan Custom User Model dengan role guru dan siswa untuk membedakan hak akses pengguna.
3. Menggunakan JWT untuk autentikasi sehingga setiap request yang membutuhkan akses harus menyertakan access token.
4. Menggunakan relasi ForeignKey untuk menghubungkan guru, kelas, siswa, dan tugas.
5. Menggunakan UniqueConstraint untuk mencegah siswa terdaftar dua kali pada kelas yang sama dan mencegah duplikasi penyelesaian tugas.
6. Menggunakan pembatasan queryset berdasarkan role dan kepemilikan kelas untuk menjaga keamanan akses data.
7. Menggunakan MariaDB sebagai database relasional untuk menyimpan data pengguna, kelas, tugas, dan status penyelesaian.

## 8. Database dan Relasi

Tabel utama yang digunakan:

- `accounts_user`: data pengguna dan role.
- `classrooms_classroom`: data kelas.
- `classrooms_classmembership`: hubungan siswa dengan kelas.
- `tasks_task`: data tugas.
- `tasks_tasksubmission`: status penyelesaian tugas oleh siswa.

## 9. Pengembangan Selanjutnya

Beberapa hal yang masih dapat dikembangkan:

- Menyelesaikan frontend HTML, CSS, dan JavaScript.
- Menambahkan pagination pada daftar tugas.
- Menambahkan validasi input yang lebih lengkap.
- Menambahkan unit test dan feature test untuk endpoint API.
- Menambahkan dokumentasi API menggunakan Swagger/OpenAPI.
- Meningkatkan tampilan agar responsif pada perangkat mobile.
- Menambahkan notifikasi pengingat deadline tugas.

## 10. Status Pengembangan

Proyek masih dalam tahap pengembangan.

Fitur backend yang telah dibuat meliputi autentikasi JWT, pengelolaan kelas, pendaftaran siswa ke kelas, pembuatan tugas, daftar tugas, pencarian, filter, dan penandaan tugas selesai.

Beberapa fitur masih memerlukan pengujian lebih lanjut dan penyempurnaan, khususnya pagination, frontend, automated testing, dan dokumentasi API.

## 11. Developer

Class Task Tracker merupakan proyek pengembangan aplikasi untuk kebutuhan penilaian teknis.

